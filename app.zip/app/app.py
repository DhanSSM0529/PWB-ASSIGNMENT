from flask import Flask, render_template, request, redirect, url_for, session
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required
from pymongo import MongoClient
import os

from bson.objectid import ObjectId




app = Flask(__name__)
app.secret_key = "your_secret_key"

# Database setup
client = MongoClient("mongodb://localhost:27017/")
db = client['social_app']

# Flask-Bcrypt for password hashing
bcrypt = Bcrypt(app)

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(UserMixin):
    def __init__(self, username, id):
        self.id = id
        self.username = username

@login_manager.user_loader
def load_user(user_id):
    user = db.users.find_one({"_id": ObjectId(user_id)})
    if user:
        return User(user["username"], str(user["_id"]))
    return None

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/register', methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = bcrypt.generate_password_hash(request.form["password"]).decode('utf-8')
        db.users.insert_one({"username": username, "password": password})
        return redirect(url_for('login'))
    return render_template("register.html")

@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        user = db.users.find_one({"username": username})
        if user and bcrypt.check_password_hash(user["password"], password):
            login_user(User(user["username"], str(user["_id"])))
            return redirect(url_for('dashboard'))
        return render_template("login.html", error="Invalid credentials. Please try again.")
    return render_template("login.html")


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    posts = list(db.posts.find())
    return render_template("dashboard.html", posts=posts)

@app.route('/post', methods=["GET", "POST"])
@login_required
def post():
    if request.method == "POST":
        caption = request.form["caption"]
        image = request.files["image"]
        upload_folder = os.path.join("static", "uploads")
        if not os.path.exists(upload_folder):
            os.makedirs(upload_folder)
        image_path = os.path.join(upload_folder, image.filename)
        image.save(image_path)
        db.posts.insert_one({"caption": caption, "image": image_path, "likes": 0, "comments": []})
        return redirect(url_for('dashboard'))  # Redirect to dashboard after posting
    return render_template("post.html")


@app.route('/like/<post_id>')
@login_required
def like(post_id):
    db.posts.update_one({"_id": ObjectId(post_id)}, {"$inc": {"likes": 1}})
    return redirect(url_for('dashboard'))

@app.route('/comment/<post_id>', methods=["POST"])
@login_required
def comment(post_id):
    comment = request.form["comment"]
    db.posts.update_one({"_id": ObjectId(post_id)}, {"$push": {"comments": comment}})
    return redirect(url_for('dashboard'))

if __name__ == "__main__":
    app.run(debug=True)
